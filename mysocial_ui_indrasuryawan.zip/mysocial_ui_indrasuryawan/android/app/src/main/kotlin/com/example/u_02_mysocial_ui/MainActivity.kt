package com.example.u_02_mysocial_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
